
from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "keep it secret, keep it safe."

# what is the default request method when declaring a route?
# GET Request
@app.route("/")
def index():
    return render_template("index.html")


# NEVER RENDER ON A POST REQUEST ALWAYS REDIRECT TO A NEW ROUTE
@app.route("/process", methods = ["POST"])
def dojo_survey():
    print(request.form)
    #request.form is a dictionary
    #session is a dictionary
    session['name'] = request.form['name']
    session['Dojo_Location'] = request.form['Dojo_Location']
    session['Favorite_Language'] = request.form['Favorite_Language']
    session['comments_optional'] = request.form['comments_optional']

    return redirect("/result") # REDIRECT MAKES A NEW GET REQUEST

@app.route("/result")
def display():
    print(session['name'])
    print("SUCCESSFUL REDIRECT")
    return render_template('results.html')


if __name__ == "__main__":
    app.run(debug = True)
